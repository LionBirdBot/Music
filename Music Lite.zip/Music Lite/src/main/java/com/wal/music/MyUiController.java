package com.wal.music;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class MyUiController {
    @FXML
    private Button profileButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button previousButton;
    @FXML
    private Button playButton;
    @FXML
    private Button pauseButton;
    @FXML
    private Button nextButton;
    @FXML
    private TextField searchField;
    @FXML
    private ProgressBar progressBar;
    @FXML
    private Label currentTimeLabel;
    @FXML
    private Label totalTimeLabel;
    @FXML
    private TableView<?> musicTable;
    @FXML
    private TableColumn<?, ?> titleColumn;
    @FXML
    private TableColumn<?, ?> artistColumn;
    @FXML
    private TableColumn<?, ?> playsColumn;

    private MediaPlayer mediaPlayer;
    private Media media;

    @FXML
    public void initialize() {
        try {
            // Example media file path (Ensure this path is correct)
            String mediaFilePath = "file:///path/to/your/media/file.mp3";
            media = new Media(mediaFilePath);
            mediaPlayer = new MediaPlayer(media);

            mediaPlayer.setOnReady(() -> {
                Duration totalDuration = mediaPlayer.getTotalDuration();
                totalTimeLabel.setText(formatDuration(totalDuration));
            });

            mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                progressBar.setProgress(newValue.toSeconds() / mediaPlayer.getTotalDuration().toSeconds());
                currentTimeLabel.setText(formatDuration(newValue));
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void onProfileButtonClicked(MouseEvent event) {
        // Handle profile button click
    }

    @FXML
    void onLogoutButtonClicked(MouseEvent event) {
        // Handle logout button click
    }

    @FXML
    void onPreviousButtonClicked(MouseEvent event) {
        mediaPlayer.seek(mediaPlayer.getCurrentTime().subtract(Duration.seconds(10)));
    }

    @FXML
    void onPlayButtonClicked(MouseEvent event) {
        mediaPlayer.play();
    }

    @FXML
    void onPauseButtonClicked(MouseEvent event) {
        mediaPlayer.pause();
    }

    @FXML
    void onNextButtonClicked(MouseEvent event) {
        mediaPlayer.seek(mediaPlayer.getCurrentTime().add(Duration.seconds(10)));
    }

    private String formatDuration(Duration duration) {
        int minutes = (int) duration.toMinutes();
        int seconds = (int) duration.toSeconds() % 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}
